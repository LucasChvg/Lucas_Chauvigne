<?php
	include ('connexionbdd.php');
	$IdPlante = $_POST['IdPlante'];
	$sql = "INSERT INTO `cultive` (`id_plant`) VALUES ($IdPlante);";
	$db->query($sql);
	$sql2 = "INSERT INTO `data`(`id_plant_capteur`, `data_eau`, `data_temperature`, `data_humidite`, `data_expo`) VALUES ($IdPlante,0,0,0,0);";
	$db->query($sql2);
?>